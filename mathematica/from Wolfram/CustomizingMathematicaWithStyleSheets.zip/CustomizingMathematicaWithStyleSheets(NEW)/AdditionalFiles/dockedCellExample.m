Cell[BoxData[
  DynamicModuleBox[{
    $CellContext`searchString$$ = "",
    $CellContext`replaceString$$ = "",
    $CellContext`tmpDir$$,
    $CellContext`matchCaseSelection$$ = False,
    $CellContext`wholeWordsSelection$$ = False,
    $CellContext`wrapAroundSelection$$ = False,
    $CellContext`fileNames$$ = {},
    $CellContext`file$$ = {}
}, 
   TabViewBox[{{1, GraphicsBox[TagBox[RasterBox[CompressedData["
1:eJzt3XuQZGV5wOG9IiDITdzEGJD1AoqiFWIUNQlI4iUqQdEiqKUFioSY7CIq
ihd4T8/uApJQisRkvYdoooMakCTGICqKSgRELNDSiKKCwILL/eoum9lQ1HJm
p0/P7PR8b3ef53krWuaP7XfO+X49t56ZPY5Y/vI3Lpg3b95btp74j5cf/vYD
jj328OMP2XHif7xy2VuOPmrZkW940bK3HnnUkcc+64iFE//PeQse+L+N/wUA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAEAJ8cTqZXFcnBGfiPGBnLPi/BMvjiviJyf+sh8Ta+K2uPPEO+OW
E6/rz784InPdxBW5M+6cuDpr+vMvxk/iiuo7E3fvrPQzNPV8Ij4wcfIPHntC
doMZYut4RXwqfhUbjGn5XBv/XB1y+sOymyxlxe4Tz3w3p191YwZp1sbpsVt2
m3Nt5ZL4cNyXfq2NGcS5N1av2jW70Tkzv3qT9/vGNM7a6uh587NT7b9Vu8S5
6dfWmGGYL8TO2b3219iT4ur0q2rMsMxPY6/sZvun88y4Kf2KGjNMc2Pnmdnd
9kc8JdamX01jhm1u6Twtu93ZW7G77/Ibs0VzTTwmu9/ZWb04vpl+FY0Z1rko
tspueDbi1PQraMwwz8nZDW+52Cd+k379jBnm+U08PbvjLTQ/vj3Nt/H2uDwu
iPPSpveed8Xa+PUsZl3Xf/nuWf27wz53d70u62b1766duGM97mn1rcQTd0F8
P+6YZh0XDufrgeKgabxtP48TOk+LBbmbVu9q3PFL8ZTZPkL8uOu/fkY/3oJh
FWd0vS4/nu2/3XlqfLmx/+P78RbMwvyJkx/xi96VVC9O3nSLxEU93q5bq79Z
vTh7y43iPxq2/NfxhX14BP1PaS77nzdvfGF8uuHOnjv7R5i92CqOiVt7lPKt
7C1nLv6gx9t0eSzN3vFBcVnXLW+MR/TlEfQ/pbntf968k3doeOXZpf14hH6I
x098NtBcy+9n7zhT8YHGt+c7J++QveEmcX3XPf+hT4+g/ynNdf8Tj7C66yNc
159H6IfYMS5u7OV92RvOTCyINQ1vzS/jUdkbbhKLYn3XTZf16TH0P6UC/S/r
+gjrY1F/HqMfVi5pfJ3cdcP1NcB4etOzWfWn2fs91KkPb9j0yP48hv6nNvf9
V0d2v7unPrw/j9Ef8cKmZmKf7P1monpzw1syEF932UT/efT/UPHFhpO4PHu7
mYgzG/rfP3u7Ov3n0f9DVQc2VPOJ7O1mIv6n69tx7aB9JqP/PPp/qFjQ8JXo
b2dvNxMN33X5l+zdJtN/Hv3XNbxeYU32bjPR8Lr/d2fvNpn+8+i/Lk7ouu29
2btN32nbNBR1VPZ2k+k/j/7rqqO7bzs8fyHg5B0aijo8e7vJ9J9H/3XV4d23
HaRXzDXT/2T6n5r+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
nv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rfnv7z6L9O/+XpP4/+6/Rf
XpH+r+z6GFfE6hZPw3Xpz5XXf3n6nyy+0v0xzJRzXn+uvP7L0/9k8cn0noZt
/qk/V17/5el/sjg2vachm+rN/bny+i9P/5ONPS67p6Gbpf258vovT/+bi++m
FzVMc0m/rrv+y9P/5uLg9KaGaKqX9uu66788/U8lLsyuamjmgv5ddf2Xp/+p
jO0RN6aXNQxz09jj+nfV9V+e/qdWHRD3ptc16HNv54/7es31X5z+u+k8J25I
L2yQ56bqgP5ecf2Xp//uJj4L+EZ6ZYM6F4zt0e/rrf/y9N8sDopL0lsbtLkk
XjIX11r/5em/t4mPA46JM+O8uDKuavFcOXEFzqyWx2Pn6jrrvzz9Myj0X57+
GRT6L0//DAr9l6d/BoX+y9M/g0L/5emfQaH/8vTPoNB/efpnUOi/PP0zKPRf
nv4ZFPovT/8MCv2Xp38Ghf7L0z+DQv/l6Z9Bof/y9M+g0H95+mdQ6L88/TMo
9F+e/hkU+i9P/wwK/ZenfwaF/svTP4NC/+Xpn0Gh//L0z6DQf3nD1X8sinVd
t12evR2zUy3vehbXjS/M3m4y/WeI67ru+6Hs3Zid+GjXe/ur7N02p/8McWnX
fdeetFP2dmy52Dlu7npvL87ebnP6zxDndt83zl69OHs/tszqxXFO053N3m9z
+s9Qvb3hlGyIr8ezsjdk5jr79fhLy8dlb7g5/WeIvRrPyca5IS6LS8zQzGWx
ptc9Hdsz+9xtTv854kc9nwHMaM0Ps8/cVPSfo3pP+nk0Zeed2WduKvrPEdvF
9ekn0pSbG07ZPvvMTUX/WeKv08+kKTbVUdnnbWr6z7J6cVyefSpNobksFmWf
t6npP8/YHnFj+sk0cz83rNg9+6x1o/9M8dy4N/10mrmd+2L/7HPWnf5zxcvj
jvQTauZu7oiDs89YE/1ni33i6vRTauZmrunsm32+muk/38olcXb6STX9n8+v
XJJ9tnrR/2CIZ8UF6efV9G8uij/KPlPTof/BEfvH++Nn6SfXzG5+NnEX988+
S9Ol/0ET+1SHVsvjvXFmjJuhmTPjvdXy6tDOU7PPz8zoH9pL/9Be+of20j+0
l/6hvfQP7aV/aC/9Q3vpH9pL/9Be+of20j+0l/6hvfQP7aV/aC/9Q3vpH9pL
/9Be+of20j+0l/6hvfQP7aV/aC/9Q3vpH9pL/9Be+of20j+0l/6hvfQP7aV/
aC/9Q3vpH9pL/9Be+of20j+0l/6hvfQP7aV/aC/9Q3vpH9pL/9Be+of20j+0
l/6hvfQP7aV/aC/9Q3vpH9pL/9Be+of20j+0l/6hvfQP7aV/aC/9Q3vpH9pL
/9Be+of20j+0Vwv6/2D1StOXeUHnOZ2nxdLYed787DtOf4x+/2YO5s64LD4T
Y9VhK3bPvvfMhv7NLOeq+Ej16pVLss8AW0L/pi+zPi6MN56yffZJYGb0b/o4
t8eZ8XvZp4Hp07/p+1xYHZh9Ipge/Zs5ma/Fs7NPBb2NRv/xyPTzbibP/fGx
VbtmnwyajUj/j0g/7WaqWVsdHQuyTwfd6d/M8Xw1Hp19PuhG/2bOZ028MPuE
MDX9mwKzPlb4PGAQ6d8Ums/H1tnnhMn0b4rNV4bnRLXF6PdfvT2Wmn7M2J6d
fasDq5dVb4uPxDfiti14BviunxMYLKPffxyRvd1oikWd/eKd8bWJz+1n8gxw
eeyYvTmb6J/ZWfG78Y64cgbPABf4OsDg0D/9EH8S35r2M8A5sSh7Xx6gf/ql
OnDio/vpPQO8P3tXHqB/+icWVcvj1uk8A1SHZO/KRvqnv+Ix8fVpPAPcEkuz
N0X/9N/4wohpfFfge74OmE//zIU4KO7q+QzQyd4S/TM3Os+MG3v0f+/Yntlb
tp3+mSudvXs+A3wpe8e20z9zp/OMuL3HM8ArsndsN/0zl6oXxH2N/V/ltUCZ
9M/cirf2+AjgNdkbtpn+mWPz4+zG/n/gN4PkqV7fcGe2y95uuvQ/yGLnuLbx
GcDXANLEsV3vyvrheV7W/2CrDm3s/6Ls/dorzuh6V27L3m369D/o4ouNzwB7
Ze/XVnFJ13vyw+zdpk//gy72inUN92gse792it0aXqd9dvZ206f/wRefarhH
V8+bn71fG8WKhnuyKnu76dP/4Ovs3fQzQZ0/zN6vfVYuiVsauhmiv9mg/2EQ
54zGe5sRMT8+13A/7hue7/7pfzhUL2u4S74HUFi8s+FubIgvZu83E/ofBrFV
w88DrfN7gUuqjo/7m/qvXp294UzofzjEBxvu00HZ27XFxOf9n218378hbopt
s7ecCf0Ph3hJw306NXu7NohHR8TNPerfECdk7zkz+h8Op2wfv+l6ny6tXmnm
bA6Lv4q/jW82vgrjwbn5pJ2yT8rM6H9YxEXTOH8mdao3ZZ+SmdL/sIj3Z59u
02MuHl+YfUpmSv/DYuKj0OzzbZrmtmH8nYz6HxbVgekn3HSf+6vDsk/IltD/
sIjd0s+46TrVu7LPx5bR/7CI7bLPuOk6f5d9OraU/ofG/PRTbqaa++Pd2Udj
y+l/eJzY+y+DmdJz+3C93ney2LbhbXtj9nY8VNydftpNfb479L9/aX7D65qO
zV6Oh6qa/x6AKTu3xLJR+AsM3X+TQXVi9m5scvrD0k+8eXDWRrVql+wT0R/x
i65v5dB+VXMUrdo1/dSbjb/b+/zqdcP0Gz56iR90fVs/m70bm3T2TT/77Z31
8dP4rzit+vNh+/me3uKrXd/qK7J3Y5N4VffzOfb8k3YyczWnbZN97+dS/GPX
c3XP8P08w+iKquH9087Z2zGs4piGc/Xk7O14UPxb17u0Jns3hlf1ou79D9/P
M4+qWBA3db1P38jejuEVSxve/38uezse0PjVv49kb8cQmx9rup6sX4/CKxxG
QRzX8FHa0dnbMcxivOFsvTh7OzaKSxve/z8xezuGWfxlw9n6dPZ2TNyhJzfc
oWuzt2O4jT2h4XTd7a9L5IuTG+7QmdnbMezi6obPAI7P3q7tYruGr/1viNdm
78ewa3z/ctMovdp5GFVv8/EZc6nx88sNcUz2fm122jZxXcO9+Uz2foyCuKTx
I4BHZu/XXnFC03Oz78/QD7Gs8SOAD2Xv11Yrdo87G+7LDasXZ2/IKDhpp7it
4Zytj2dnb9hOcW7j8/KK7P0YFXFK40m76uQdsjdsn8ZXZmyIO1btmr0ho2Ll
ksaPNDfEWdkbtk3nqXFX4x3x+5noozi98bT5PkBRsXP8qPFu3BOPzt6RUbLi
d+L2xhO3vjo0e8e2iG3jmz2ejd+XvSOjpumnzP5/7qtekL1jG4wvjM/3uBPX
e90P/RaL4ns9zt2dvuM8105/WJzV4y5siFdlb8koiufG/T1O3rrq9dlbjrLY
Mb7es/4L5s3P3pPR1PD7QB+c+6PjN4POjXhyXNnz+t8xtmf2noyq2Dou63kC
N8TXfPW5/+K1cUfva1+9LntPRtnYnj2+D/DA3OBz0H5a+dvxmWlc9Q3x8exN
GXXVodM6iROfh3b2zt51FMSianncOq0rfkVsm70to6/Hq4E3zX3x8aH/G8ip
Yqs4In48zat9w9gTsvelFebHx6Z5Jjf+dNB4PC8WZK88fOK3qrc0/P3VyXNb
Z9/sjWmLWBTnTPtkbpxfxEmdZ/i+wPSsXBKvif+MdTO4vvdUB2ZvTZuctk18
eUbPABvnlvhCvDX+LB7vLwdsbtUunf2qw+MDE5/F93qVxeS5tzoke3vaZlqv
ROt6YuOa+FFcEufHea2fb8f346ppfoVvqrk9np99Fmij8YXxwS0+taY/8+vO
ftnngPaq3hPr0xto7/yvv+9Drnhe4++gNXM3n/NzfuSLR8V/p7fQtrm7Wp59
3+EB4wvj3XF3ehPtmYtjn+x7Dg8VS+Pf07tow9xcLfdKCgZRHBw/S+9jlGd9
fNTv9WVwrV4cr40fpncyirM+xseelH1/oZfxhfEXPX9XmJnJ3BV/H4/Nvq8w
fZ294+S4Pr2cYZ/1cWG1fNUu2XcTZm714uql8fH4eXpFwzh3x1fiHbFb9j2E
2Rp7XLwhPhVXxD3pVQ3+XBPnR6c6ILbOvmvQX+MLY2m8MJbFCROfG6yOT8a4
mZgPx/tiZRxXHdbZ95Tts+8RAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADK7/A4kekH8=
        "], {{0, 0}, {512., 512.}}, {0, 255}, 
          ColorFunction -> GrayLevel], "Image"], ImageSize -> 30] -> 
       TagBox[GridBox[{{ButtonBox["\<\"...\"\>", 
            Appearance -> "FramedPalette", 
            ButtonFunction :> SystemOpen[ParentDirectory[]], 
            Evaluator -> Automatic, Method -> "Queued"], 
           TemplateBox[{1}, "Spacer1"]}, {PaneBox[
            TagBox[GridBox[{{DynamicBox[
                 ToBoxes[$CellContext`fileOpenerGenerate[
                   NotebookDirectory[]], StandardForm], 
                 ImageSizeCache -> {368., {161., 
                    13.}}]}, {TemplateBox[{1}, "Spacer1"]}}, 
              DefaultBaseStyle -> "Column", 
              GridBoxAlignment -> {"Columns" -> {{Left}}}, 
              GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
                "Rows" -> {{Automatic}}}], "Column"], 
            FrameMargins -> 0, ImageSize -> {Automatic, 100}, 
            ScrollPosition -> {0., 0.}, 
            Scrollbars -> {Automatic, True}], ""}}, 
         AutoDelete -> False, 
         GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
           "Rows" -> {{Automatic}}}], "Grid"]}, {2, 
      GraphicsBox[TagBox[RasterBox[CompressedData["
1:eJzt3Xm8VWW9x3HgyOQIDjnkgIjzFJFdQlBTcEglHCivJWYGOOQQmkY36/us
DRy4JMWpzHOtNBzSkxqJmeM1FVG7mljmHM5TenEgAUXOuftEXODIetba++y9
f3ut5/N+Xk3+03ev9TzfvdY+a9j+q2cdPa5bly5dzulV/LejTzr/sxMmnDTx
mD7F/zH6zHNOHX/m2K8ddua5Y8ePnTD4qw3Ff9il24p/tf8HAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAkH/qoT2iQZO2sc4BoLa0tX6mRWr753jCjW9p
sE4EoDai/fW//1r7K8ct0zawTgWg+go76t0Oq799zKUBgPzTnLWsfhoACEDx
zL81Zv3TAEDO6djY1U8DADnnxnvXPw0A5Jg7JmH90wBAbk3eUstpACBUui5x
/dMAQE6pnxbSAECoNOT/r/2lAYDgRPuu9RrAjuNeGgDIIxoACBkNAISMBgBC
lrIB+CUQyCUaAAgZDQCEjAYAQkYDACGjAYCQ0QBAyGgAIGQ0ABAyGgAIGQ0A
hIwGAEJGAwAhowGAkNEAQMhoACBkNAAQMhoACJmG0gBAuGgAIGQ0ABAyGgAI
GQ0AhIwGAEJGAwAhowGAkBUbIM3bw++hAYA8ogGAkNEAQMhoACBkNAAQMhoA
CBkNAISMBgBClrYBtL51UgCVRwMAIaMBgJDRAEDIaAAgZDQAEDIaAAgZDQCE
jAYAQkYDACGjAYCQRcNoACBcNAAQMhoACBkNAISMBgBCRgMAIaMBgJDRAEDI
UjbA3TQAkEc0ABAyGgAIGQ0AhIwGAEJGAwAhowGAkNEAQMhoACBkNAAQMhoA
CBkNAISMBgBCRgMAIaMBgJDRAEDIaAAgZDQAEDIaAAiZ9qMBgHDRAEDIaAAg
ZDQAEDIaAAgZDQCEjAYAQkYDACErNsA/UjTAXTQAkEc0ABAyGgAIGQ0AhIwG
AEJGAwAhowGAkNEAQMjSNsD09ayTAqg8GgAIGQ0AhIwGAEJGAwAhowGAkNEA
QMjcCC2mAYBQ0QBAyGgAIGQ0ABAyGgAIGQ0AhIwGAEJGAwAhowGAkKVsgFtn
9LZOCqDyaAAgZDQAEDIaAAgZDQCEjAYAQkYDACGjAYCQ0QBAyGgAIGQ0ABAy
GgAImQ6mAYBw0QBAyGgAIGQ0ABAyGgAIGQ0AhIwGAEJGAwAhKzbAEhoACFXK
BriFBgDyiAYAQkYDACGjAYCQ0QBAyGgAIGQ0ABAyGgAIGQ0AhIwGAEJGAwAh
owGAkNEAQMhoACBkNAAQMhoACFnaBlAv66QAKo8GAELmDqEBgHDRAEDIaAAg
ZDQAEDIaAAgZDQCEjAYAQkYDACFL2QA30wBAHtEAQMhoACBkNAAQMhoACBkN
AISMBgBCRgMAIaMBgJDRAEDIdCgNAISLBgBCRgMAIaMBgJDRAEDIaIAuXaZu
1Ni3sS9vRUKIwmiApp7ayR3ixivST3S17tB8vaiFeu8jn3NhcTyt+/U7zdIM
N9F9SUO0lXV6oHry2gDqEw3TabpYd+tltab4hPFjiR7XHDXquGj35u7Wnwuo
rJQN8PssNEBTz2hf903N1nOdWvHx4309rP/SGA2w/qRApWS/AZp6uhGaqrla
WqV1/9Hxqq5zZ2kX608OdF52G6CwvcapRe/UbN13HM+q2Y2eupH1dgA6I3sN
oF30XT1qtu7XHEs1x52gDa23CVCu7DRAYQd9W/PN1/xHxxL9xv379PWstw9Q
jvpvgOJ5/mjd1snf86s93tUsDbfaQkD56rkBoj01UwvNV3fa8bA7XX1qv5WA
zqjPBtBQzanzb/21jUVq1k613E5AZ9VXA6iHxugv5iu5/LG82FyDa7GlgMqo
lwZQL52tV8xXcCXGHdGw6m4roHLsG6C5u8bpJfN1W8kxV/tVa2sBlWXZAC0N
7uSqXMG7vNgo83WHrtaP5dz57nydVmyZFePsf/7v/9TPNbu4Uh/XW1XpgDn6
ROW3F1B5Vg2gA/VIBVfcs7pBjW6sG1HYUT1KydHYNxrojtIE/bTYB29XLM9y
XTJ588puMaAaat8AhR10fUVW2QJdXvxuH1q563LVzx3pvqdb9W4F0r3jvlla
FwEWatkAWleNnb5/50nNdKOrec9+S0M0UF/XtZ0+InjKHVa9lEBl1KoB3EF6
phOr6T3d6E5X/8p85jS0TrR/sa8e7lQHXKmP1S4xUI7qN4D6qLnsq3uWaI7G
TNugkp+4pOzburM0t+wGeEvjunS1yg6kUd0G0NF6ray1s7z4/3i83cpfnXbS
d7WgzA64ddI21vkBn2o1wIzemlnWmnlZU2t5tJ+Gumlo8ThmcRmf5m0db50e
8HGHVb4Bon30VBmr5Q53ZEtD9T5p52hTd35Z1y1dqvWtswPxKtsA6uYm6oMS
18gyXaVPVvtzdp56uBP155Ib4OloH+vkQLzKNYD6aE6Jq+N9/WTSdrX4lBXS
tXjOdH+Jn3GpG28dG4hXmQbQLnqspHXxgWYVdqjVZ6wkDdf/lNgBs7SudWog
TucbQMev5c0b8aNVV2Rz7f9LV3eUHi+pAR7M1HEOAtOpBuiqqSWthfujf6v5
B6y45u46u6T7id7QEOvMQJxyG6Cpp64sYRW8rHHqZvMJK08ba6aWpf7sS/mL
IOpXOQ1QXAF3pZ7/rWqujyt7KinaW38sYQvIOi8Qp9gAae7VuWllA2iAnk49
9/+S1ydmaR2dV8IVQs31e50DQldKA2gPvZpyzn+g7+b73tjCDrozdQO05Htb
IMtSN8BgvZFyvi8I4pevru4svZ9yi/xuRm/ruMDauSNTzeO01/nNCuca2GiQ
nki5Vf6Qv19CkBcpGyB5vO2Osf4stTV9Pf0i5baZx5sFUa8q0gBPaDfrz2FB
Y1L+GngvbxVEvep0A8wO9/3Z+qSeTbWNbm3qaZ0VWLtONMBynWud3taUzVJe
F3Etfw1EvSqzAd5zR1knt9fUU1ek2lqX8qww1KsyGuBNDbVOXSe6Sqm2mKyD
AnE0sqQGeKKwvXXieuJOSnF/QKs70TonEKe9Ab6XbvX/tZpP6c+m4hFU8l0V
H7gR1jmBOBrpPkyx+h/QxtZJ65EOTfFshLfC/FspskBHpHiS/91czxInGqZ3
Erffk+H+vRT1TANSPOdiXjhX+ZZDg7UocRv+lr8EoN7M6K0/Jc7chxv7Wues
d+6gFL8DfMs6JbAm/TJx1v5lyibWKbNAIxPvmVruDrFOCazixieu/r9pC+uU
WaHjE39HeX3y5tYpgRWKZ/5JZ63/W9jZOmWWuImJfXozvwKgHjR31wMJc/V9
HWidMmt0UVIDuDOsMwLFmZr0VO9Wd4J1xuxpaUh8S9JS7WWdEqGLhml5wjx1
1hmzSRsmvjvkEZ4QCEtNPRPf5nUrd66Wq7Bz0vVA7gLrjAiZJies/ue0qXXG
LNOohL8ELOV6YFiJ9kz4S/WSLLyxu77p+wkNe19+3pOELGlpSHqjjRtrnTH7
tI7mJTTAKdYZESJ3esK8/I11wnxQ/4RfAd7Wx6wzIjSNfRPe6/EyZ/6VojEJ
TXuxdUKERjO9M7LVHWadME8S3p28PBpknRAhKeya8MvfRdYJ82XqRsXjKd/2
voergVE7utk7G1/iGR+Vpi8knAMca50QoXAHJczFUdYJ80izvdv8Ka1jnRBh
0N3emXiNdb580lZ627vdv2KdECFwh3ln4SKe7Vst7hveLb+gubt1QuSf/25f
N9E6X341d094b/g464TIO430fwepl3XCPHOHe7f+C7wnFNXlvxrVHWOdL+90
k3f7n2ydD3kW7ev9/rnbOl/+aTf53rHyGNcBoHp0vXf9H2CdLwS63HsEcLh1
PuSV+nu/e263zhcGDfC+K/RO63zIq4RnUg6xzhcK/dy3H6J9rPMhj6Zt4H3K
903W+cKhft67Ly6zzoc88r/jI9rfOl9IvL8BLFYf63zIHz3omXMPWqcLi/by
PRfQnWqdD3lTnHG+c//jrPOFRrd59sZ863TIG+9vfy9y5XmtuUO8fcxzV1FB
6qGFntl2nnW+AHX1vnmhyToe8kRHeObaB7zZ14I7x7NPXuWtK6gczfLMtV9b
pwvTlE20NH6v8PcYVEpTT++TJw62zhcqXePZKz+xToe8cJ/3zLPneP+MFTfC
s19e53lgqAxd4ZlnjdbpwtXSoFc9e+ZA63zIg+Ise9NznjnQOl/I9GPP+v++
dTrkgQZ75tgz1unCpv08++ZR63TIA8kzxwrW6cKmbnopfu9M2s46H7JP93uO
/ve2Thc673vYeB4oOkmbanns/HqRp01Z814HfL11OmSdO8Yzvy6xTgf10nux
+2chf5tF52iGZ/0fbZ0OCU8E3s06HbLNc/a/bOpG1ulQPEI7g18AUB0zeuv9
2Lk11zod2mkXz/r/pXU6ZJn378vTrNPhn7rq77H7iOsz0An6Vvz6d5+3TocV
fG8Gn7y5dTpkl66KnVmtUzazTocVdJ6npUdYp0N26dHYmfWkdTas5H0r2wTr
dMiqpp6e58zPsk6HldTL80agy6zTIav0Cc9x5Tet02EVz7MAeTI7yqQxnvV/
iHU6rOJ5EtASngSI8mhK/PqfvKV1Oqyib3t+ARhgnQ7ZpF/Fzqk3rbNhdRrp
Wf/DrdMhm3Rf7Jy62zobVqcBnjO1sdbpkE16LXZWcV1pXVEPz13ak63TIYtm
9Pa8Y1LW6bAmvRi7r66yzoYsKuzqOaY8yTod1qS7YvfWfdbZkEXus57flA6w
Toc1ed7QtMA6G7JIx3rWP39TqjOaFLuvFllnQxbpFM/672OdDmvShPi91dTT
Oh2yR9+JnVHLeO5nvfFdq8m1WiidfhA7o163zoaO3OGeo7U9rNMhezy/KP3V
Ohs60qc96/8A63TIHv06dj7x5L+6U9jRs/4/Z50O2aMbYufT7dbZ0JG29az/
UdbpkD26OXY+3WSdDR1N3jx+/bsvWqdD9ujO2Bk12zobOmrs6/n+H2OdDtmj
e2PnU4t1NnSkdT3f/9wBiJLpj7Ez6krrbOioubtn/Z9unQ7Zo3mxM+pq62zo
aEZvz/E/bwFDyTzn/7xXuu6oj+f7/0TrdMge3RI7o260zoaO9DHP9/9x1umQ
PZoTO59us86GjiZt41n/vKcdJdO1sfOJp//VncIOnuP/w63TIXt0ReyMesQ6
GzqKBnnW/0HW6ZA9+lHsjHrJOhs60sHx6z8aaJ0O2SPFzqgl1tnQkY73nP9v
a50O2aOvx8+o6etZp8Oa3Bme9b+udTpkj47zzKh+1umwJrnYfbXYOhuyyI3w
rP8h1umwJv0sdl+9aJ0NWaS94te/+5J1OqxJt8fuLd4AjjJoQ8/6/w/rdFiT
/ha7t661zoZs0sLYOXWJdTasrqVBH8Tuq+nW6ZBNeih2TnEFcF3xPf2Lu39R
Hl0XO6uet86G1fl+q+XqX5RHF8bPqsa+1umwiu/tP9rNOh2ySePiZ1W0v3U6
rKJLY/fUMvWyTods0hDOKrPB80vNY9bZkFXTNlBr7Ly62DodVmpp0OLY/XSN
dTpkl+evyg9ZZ8NK0d6es//vWKdDdml27Lz6cNoG1umwgk7zrP+R1umQXZ67
SniqRN3QlZ713886HbJLn/Os/wus02EFPRe7l16zzoYsUx8tj51bt1inQztt
7fn259p/dIoejZ1b/2jqaZ0OXbq4Ez3HaN+wTodsU7Pn22W4dToU99DVnj30
aet0yDbft4sutE6Hlga9Gbt/FquHdT5k26TtPOufa8vMRZ/x7J/brdMh+/RY
/AwrbG+dLnSKPOv/XOt0yD7N8Py+dI51utB5fp9ti3a3Tofs871ZQg9Ypwub
9vDsG577iQpo6qlFnjOAHazzhUwFz/pvtk6HfPC8CbjNnW+dLmR60rP+R1mn
Qz7oK55ZNt86Xbj0Kc9+WTSjt3U+5IP6aKlnpn3KOl+o9FPPXrnKOh3yw3cG
wHmmjRm99RZH/6gFd4LvSJMnAVhwJ3n2ybsc/aNypm2gJfGzzZ1snS9Eutez
/mdZp0O+eO8yeaRLV+t8odFenmcztrkR1vmQL+4gz/pv04HW+UKjKzx7Y4G6
WedDznTV054Z9zvreGHR1p73/fF2VlSBm+hZ/628ZaaWfG9m0oeTtrHOh/zR
Fr7vHF1qnS8cjX31jmdP3GCdD/mkFs+sW1bY0TpfKDTZ91uMO8w6H/Ip2sc3
73S5db4waFO969kLj/PbH6pFc33nnYVdrfOFQNO9LfxV63zIL43yzr0W63z5
py30nmcPvMIzmVE96ub9K2CrhlonzDtd4m3gb1vnQ75pnHf+PcCVgNUUDfS8
j6VNbzf2tU6IfGvu7nkncPv4snXCPNMffNvefc86H/LPe99Zm16avp51wrxy
o71b/i31sU6I/NM63qdOtWm6dcJ8mraBXvB++0+0TogwuC951/+H0SDrhHmk
H3m3+hs8hQG1oW6a752LD2sd64x5oyHeX/7adKZ1QoTDfdY7F9v0LeuE+aIe
vvd8FMfjzd2tMyIkus47H5fw7plK0hR/33LNP2pL/X1PBCuOR9XLOmNeRMP0
oXdb8/QF1JymJpwDfN86YT6oj57zbudlHGuh9rR+wrxs5Sl0leB98mL7aLRO
iDC5wxJm5iuTt7TOmHVubMI2foonfcOK9ymU7WOeelhnzLJooBb7j7E03Doj
wjVlE72e0AAzrTNmlzbWgoSte4l1RoQt4VrA9sEdQWVpadDtSedX3O8Ha/pV
wixdoiHWGbNITQnbtdUdbp0RUB89nzBT3+DZoKXShMTjqh9YZwTaJV6f0qZn
pmxmnTJLdETiFn2U3/1RLxKvBWrTXVwPmJYGe5/x1z4Wc80P6od6aF5iA9zI
3wLTiPbWwsRtOc46JbC6yVvqlcRZez33BScp7KhXE7cjb1pA3Yn29b4fbMWY
xdspfLRtwjXV7WO+1rXOCXyU+0bi3G3Tz1sarHPWK/XXs4nb7031s84JrJ2u
TNEAV/GsirUp7KqXErfdMh1snROIox767xQNMIe/BXQU7Z7i95M2d7p1TsBn
yiYJTwdeMW7R+tZJ60m0b4rf/Ns0zTonkKR4Fpt0T1D7+POkbayT1gsdnXCX
34rRwm+nyAINSTWfX9Re1knrgc5Ta4qtNZdzJmSFDtX7Keb0OzrUOqmt5u66
OMV2atNDvNsHWaJRWpZiXrdqarhHtVM20x2pVv+Tkze3zgqURscm3sOyYtwQ
5ndbtK9eTrV9ntFW1lmB0ulrCe+sWTmeCO5ulq7ujBRXS7aP57neB1ml41Od
BbRpiTs/nPOA4nH/b1NtlTYtUH/rtED59IWU33NtujWM41wNT3nc36bHJ33c
Oi3QOToi4U1Bq8brGmWdtrqmr6emVH/tax8PaVPrvEDnuYP0Tso5336VyxbW
eavFHZLi/p6V466pG1nnBSpDeyQ+I3DVeEvjunS1TlxpjX3VnPqbv9iCPN0L
eaKt9KfUs79Nd0Z7WyeunJYGjdPfS/j0hfz1H0JXPPe9oYQ1sFyz8nHVS7S/
Hi7hcy/TKdaJgWoofg9OK+EYuE1v69xsHwdrJ11bwudt02vR/taZgerRyOKq
LmVFvO7Oz+adL9q2eMaf7uqHlePBSdtZpwaqq7CrHi9pVbTpeTc2W88OLq79
i1Nf97ByXJStzwiURxvqmhLXRpteKh4HZOI+gWigrih57S/SGOvcQO3oK3q3
5A5YpB/W8/Ww6qbPJb6zc23jAQ2wzg7UlvrpnjLWynLd5kbX35GytigenzxT
1ueZWX+fBqg+rSOVfKS8YrymafVyz6B6aKRml/hL38qxIBpmnR+wE+2p+8ta
Oe3jr8X+2MUue0uDhha/vUu5smfNb/5mnoKK0BVX0YTE9136xnxNKq7Dmr5Z
TBu7L+oyvdmJ1I9E+9QyMVC/Ctvr951YS+1joVrcyYWdq5tzRu9omLtA81I+
2ShuvOcm8g4UYHU6ItWbA5LG3/Vbnaf9Knv3XLGfjtaFui/VU039o1VXautK
ZgPyQT2KZwJvVaADVoxndYMm6zgNLueO4mKWARquU/RTzS3h7uWk8cfoM5Xf
bkBeTNlMP9LSiq23lWOxHiueYVyuH7oL3Kn6gkYV1/ZwDYkGRYN0QPt/d6P1
ZZ2tgi7Sr3WPXkz55MJSxgJ3QjjPOAPKNWkbzaxCB1iOF9xZTT2ttyuQFeqv
y8r8m3q9jVfcGax9oFTqp6kV/D3AYjztzsr2HcyAJW3oztIL5uu4nDHXjW5p
sN5+QNaph47XnSU9OcR2vKuLo4HWWw3Ik8KOxbOBNG8Wtx0PahxX9QLVUDwS
OFrXdOpq4eqNBZoa7Wm9hYC8m9HbHalZ+of5il85XtBMDeWZvUDtaH2N0sUl
vFeg8uNDzdV3okGsfMBKtLvO1e9LfKpoZ8dT+oX7YmNf688OoJ26RXu6U3W5
/lbFVb9U83ShOyof7yUA8mjqRtEwnVY8M5hXkft2WvWcblSjjiseZ9T0GQMA
OmfKJtEgd4w7Rz/WbN2jx/R6wp377+kFPazbdKUa3Xh3SGFnrtwF8kQbq7/6
F3Ztv/cv2l+Do0H6ZPs/mfRxrtQFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAsub/APsP390=
        "], {{0, 0}, {512., 512.}}, {0, 255}, 
          ColorFunction -> GrayLevel], "Image"], ImageSize -> 27] -> 
       TagBox[GridBox[{{TemplateBox[{1}, "Spacer1"], 
           TagBox[GridBox[{{"\<\"Find:\"\>"}, {InputFieldBox[
                Dynamic[$CellContext`searchString$$], String]}}, 
             DefaultBaseStyle -> "Column", 
             GridBoxAlignment -> {"Columns" -> {{Left}}}, 
             GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
               "Rows" -> {{Automatic}}}], "Column"], 
           TagBox[GridBox[{{ButtonBox["\<\"Find Next\"\>", 
                Appearance -> Automatic, 
                ButtonFunction :> 
                 NotebookFind[
                  ButtonNotebook[], $CellContext`searchString$$, Next,
                   WrapAround -> $CellContext`wrapAroundSelection$$, 
                  IgnoreCase -> 
                   Not[$CellContext`matchCaseSelection$$], 
                  WordSearch -> $CellContext`wholeWordsSelection$$], 
                Evaluator -> Automatic, 
                Method -> "Preemptive"]}, {ButtonBox[
                "\<\"Find Previous\"\>", Appearance -> Automatic, 
                ButtonFunction :> 
                 NotebookFind[
                  ButtonNotebook[], $CellContext`searchString$$, 
                  Previous, 
                  WrapAround -> $CellContext`wrapAroundSelection$$, 
                  IgnoreCase -> 
                   Not[$CellContext`matchCaseSelection$$], 
                  WordSearch -> $CellContext`wholeWordsSelection$$], 
                Evaluator -> Automatic, Method -> "Preemptive"]}}, 
             DefaultBaseStyle -> "Column", 
             GridBoxAlignment -> {"Columns" -> {{Left}}}, 
             GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
               "Rows" -> {{Automatic}}}], "Column"], 
           TagBox[GridBox[{{TemplateBox[{CheckboxBox[
                  Dynamic[$CellContext`matchCaseSelection$$]], 
                 "\" Match Case\""}, 
                "RowDefault"]}, {TemplateBox[{CheckboxBox[
                  Dynamic[$CellContext`wholeWordsSelection$$]], 
                 "\" Whole Words\""}, 
                "RowDefault"]}, {TemplateBox[{CheckboxBox[
                  Dynamic[$CellContext`wrapAroundSelection$$]], 
                 "\" Wrap Around\""}, "RowDefault"]}}, 
             DefaultBaseStyle -> "Column", 
             GridBoxAlignment -> {"Columns" -> {{Left}}}, 
             GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
               "Rows" -> {{Automatic}}}], 
            "Column"]}, {TemplateBox[{1}, "Spacer1"], 
           TagBox[DynamicModuleBox[{Typeset`var$$ = False}, 
             InterpretationBox[
              StyleBox[
               PaneSelectorBox[{False -> 
                  GridBox[{{OpenerBox[Dynamic[Typeset`var$$], 
                    Appearance -> Automatic, AutoAction -> False, 
                    ContinuousAction -> False, Enabled -> Automatic], 
                    "\<\"Replace\"\>"}}, AutoDelete -> False, 
                   BaselinePosition -> {1, 1}, 
                   GridBoxAlignment -> {"Columns" -> {{Left}}}, 
                   GridBoxBackground -> {"Columns" -> {{Automatic}}}, 
                   GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
                    "Rows" -> {{Automatic}}}, 
                   GridBoxSpacings -> {"Columns" -> {{0.2}}, 
                    "Rows" -> {{0.5}}}], 
                 True -> GridBox[{{OpenerBox[Dynamic[Typeset`var$$], 
                    Appearance -> Automatic, AutoAction -> False, 
                    ContinuousAction -> False, Enabled -> Automatic], 
                    "\<\"Replace\"\>"}, {"", 
                    PaneBox[TemplateBox[{"\[ThinSpace]", "\" \"", 
                    TagBox[GridBox[{{"\"Replace with:\""}, {InputFieldBox[Dynamic[$CellContext`replaceString$$], String]}}, 
                    GridBoxAlignment -> {"Columns" -> {{Left}}}, 
                    DefaultBaseStyle -> "Column", 
                    GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
                    "Rows" -> {{Automatic}}}], "Column"], 
                    TagBox[GridBox[{{ButtonBox[
                    "\"Replace & Find Next\"", 
                    ButtonFunction :> (NotebookApply[
                    ButtonNotebook[], $CellContext`replaceString$$]; 
                    NotebookFind[
                    ButtonNotebook[], $CellContext`searchString$$, 
                    Next, WrapAround -> $CellContext`wrapAroundSelection$$, 
                    IgnoreCase -> 
                    Not[$CellContext`matchCaseSelection$$], 
                    WordSearch -> $CellContext`wholeWordsSelection$$, 
                    AutoScroll -> True]), Appearance -> Automatic, 
                    Evaluator -> Automatic, Method -> "Preemptive"]}},
                     GridBoxAlignment -> {"Columns" -> {{Left}}}, 
                    DefaultBaseStyle -> "Column", 
                    GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
                    "Rows" -> {{Automatic}}}], "Column"]}, 
                    "RowWithSeparators"], ImageMargins -> 0]}}, 
                   AutoDelete -> False, BaselinePosition -> {1, 1}, 
                   GridBoxAlignment -> {"Columns" -> {{Left}}}, 
                   GridBoxBackground -> {"Columns" -> {{Automatic}}}, 
                   GridBoxItemSize -> {"Columns" -> {{Automatic}}, 
                    "Rows" -> {{Automatic}}}, 
                   GridBoxSpacings -> {"Columns" -> {{0.2}}, 
                    "Rows" -> {{0.5}}}]}, 
                Dynamic[TrueQ[Typeset`var$$]], Alignment -> Automatic,
                 BaseStyle -> {}, BaselinePosition -> Baseline, 
                DefaultBaseStyle -> "OpenerView", ImageMargins -> 0, 
                ImageSize -> Automatic], Deployed -> False, 
               StripOnInput -> False], 
              OpenerView[{"Replace", 
                Row[{Column[{"Replace with:", 
                    InputField[Dynamic[$CellContext`replaceString$$], 
                    String]}], 
                  Column[{Button["Replace & Find Next", 
                    NotebookApply[
                    ButtonNotebook[], $CellContext`replaceString$$]; 
                    NotebookFind[
                    ButtonNotebook[], $CellContext`searchString$$, 
                    Next, WrapAround -> $CellContext`wrapAroundSelection$$, 
                    IgnoreCase -> 
                    Not[$CellContext`matchCaseSelection$$], 
                    WordSearch -> $CellContext`wholeWordsSelection$$, 
                    AutoScroll -> True]]}]}, " "]}, False]], 
             DynamicModuleValues :> {}], Setting[#, {0}] &], "", ""}},
          AutoDelete -> False, 
         GridBoxItemSize -> {"Columns" -> {Scaled[0.], Scaled[0.], 
             Scaled[0.], Scaled[0.], Scaled[0.6], Scaled[0.1]}, 
           "Rows" -> {{Automatic}}}], "Grid"]}}, 2, 
    ControlPlacement -> Left, ImageSize -> {{Automatic, Automatic}}], 
   DynamicModuleValues :> {}]], "DockedCell"]